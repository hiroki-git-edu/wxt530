
import serial
from struct import *

def AcqTemperatureAndHumidity(_device):
    com = serial.Serial(port=_device, baudrate=19200, parity=serial.PARITY_NONE, bytesize=serial.EIGHTBITS, stopbits=serial.STOPBITS_ONE, timeout=2)
    com.close()
    com.open()

    com.write('0R0\r\n')
    response = com.readline()
    print(response)

    com.write('0R1\r\n')
    response = com.readline()
    print(response)

    com.write('0R2\r\n')
    response = com.readline()
    print(response)

    com.write('0R3\r\n')
    response = com.readline()
    print(response)

    com.close()
    Temperature = 0
    Humidity = 0
    return Temperature, Humidity

if __name__ == '__main__':
    t, h = AcqTemperatureAndHumidity('/dev/ttyUSB0')
    print t, h



