#!/bin/bash
# cron 用に PATH を設定
export PATH="/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"
# ホームを明示
export HOME=/Users/hirokinakamura

cd /Users/hirokinakamura/wxt520/mac/src

#1# Data acquisition program
./daqWxt520.py      setting.txt

#2# Enformat raw data
./enformatWxt520.sh setting.txt

#3# Plotting data
./plotWxt520.sh     setting.txt
./plotWindWxt520.sh setting.txt

#4# Monitor page updater
./monitorWxt520.sh  setting.txt