#!/bin/bash
# 実行例) ./plotWxt520.sh /home/pi/wxt520/conf/wxt.conf
# 1. 設定ファイル（引数）からログ保存先（FILEDIR）とWeb公開先（WEBDIR）を取得
# 2. 当日の日付からログファイル名を生成（例：wxt20250626.txt
# 3. tenki.jp から現在の天気情報（晴れ、曇りなど）を取得
# 4. それを now-weather.dat というファイルに保存（Web公開用）


# 引数チェック
if [ $# -ne 1 ];then
    echo "Usage: plotWxt520.sh [setting file]. "
    exit
fi
# スクリプト実行時に引数が1つだけ必要 (設定ファイル)
# 指定しない場合、Usageを表示して終了


# 設定ファイルからパスの抽出
SETTING=$1
FDIR=`cat $SETTING |awk '{if($1=="FILEDIR"){print $2}}'` # データログの保存ディレクトリ
NOW=`date +"%Y%m%d"` # 今日の日付でログファイルを特定
FDATA=$FDIR/wxt${NOW}.txt
if [ ! -e $FDATA ];then
    echo "No file: $FDATA"
fi
WEBDIR=`cat $SETTING |awk '{if($1=="WEBDIR"){print $2}}'` # Web表示用のデータ出力先


# 現在の天気情報を tenki.jp から取得
weather_telop=`curl http://www.tenki.jp/live/3/17/|grep weather_entry_telop|sed 's,[<>], ,g'|awk '{print $5}'`

echo $weather_telop > ${WEBDIR}/data/now-weather.dat 


