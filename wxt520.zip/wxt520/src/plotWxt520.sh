#!/bin/bash

if [ $# -ne 1 ];then
    echo "Usage: plotWxt520.sh [setting file]. "
    exit
fi
SETTING=$1
WEBDIR=`cat $SETTING |awk '{if($1=="WEBDIR"){print $2}}'`

NOW=`date +"%Y/%m/%d %H:%M:%S"`
STRT=`date +"%Y/%m/%d 00:00:00"`
UNAME=`uname`
if [ "$UNAME" = "Darwin" ]; then
    END=`date -v+1d +"%Y/%m/%d 00:00:00"`
elif [ "$UNAME" = "Linux" ]; then
    END=`date -d '1 day' +"%Y/%m/%d 00:00:00"`
fi


THP="${WEBDIR}/data/thp.dat"
WIN="${WEBDIR}/data/wind.dat"
RAIN="${WEBDIR}/data/rain-hail.dat"
FIGDIR="${WEBDIR}/fig"

gnuplot <<EOF
  set title '$NOW'

#  set size 1.0,0.8
  set xdata time
  set timefmt "%Y/%m/%d %H:%M:%S"
  set format x "%H:%M"
  set xlabel 'Time (m:s)'
  set grid x
  set grid y
  set term png

  set output "${FIGDIR}/temp.png"
  set ylabel 'Temperature [deg]'
  plot ["${STRT}":"${END}"][0:40] \
       '$THP' u 1:3 w l lw 3 ti "Temperature [deg]"

  set output "${FIGDIR}/humi.png"
  set ylabel 'Humidity [%]'
  plot ["${STRT}":"${END}"][0:100] \
       '$THP' u 1:4 w l lw 3 ti "Humidity [%]"

  set output "${FIGDIR}/pres.png"
  set ylabel 'Pressure [hPa]'
  plot ["${STRT}":"${END}"][980:1030] \
       '$THP' u 1:5 w l lw 3 ti "Pressure [hPa]"

  set output "${FIGDIR}/wind.png"
  set ylabel 'Wind speed [m/s]'
  plot ["${STRT}":"${END}"][0:15] \
       '$WIN' u 1:8 w l lw 3 ti "Maximum", '$WIN' u 1:7 w l lw 3 ti "Average", '$WIN' u 1:6 w l lw 3 ti "Minimum"

EOF

