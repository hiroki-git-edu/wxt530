#!/usr/bin/python3


# WXT520からデータを取得し、時刻付きでログファイルに保存
# 実行例: python3 daqWxt520.py setting.txt


import serial, time, sys # serial は pyserial
from datetime import datetime as dt
from pytz import timezone

argvs = sys.argv
argc = len(argvs)

# 設定ファイル (/home/pi/wxt520/data/src/setting.txt) から保存先のディレクトリ FILEDIR, シリアル機器のデバイス名 DEVICENAME を読み取る
def getFileName(_fname):
    f = open(_fname)
    for line in f:
        data = line[:-1].split(' ')
        if data[0] == "FILEDIR":
            dname = data[1] 
    f.close()
    now = dt.now(timezone('UTC'))
    return dname + "/" + now.strftime("wxt%Y%m%d") + ".txt" # 今日の日付で wxtYYYYMMDD.txt という出力ファイル名を作る

def getDeviceName(_fname):
    f = open(_fname)
    for line in f:
        data = line[:-1].split(' ')
        if data[0] == "DEVICENAME":
            devname = data[1] 
    f.close()
    return devname

def daq(_device, _fname):
    com = serial.Serial(port=_device, baudrate=19200, parity=serial.PARITY_NONE, bytesize=serial.EIGHTBITS, stopbits=serial.STOPBITS_ONE, timeout=2) # 通信ポート
    i = 0
    errorFile = _fname + ".err"

    while i<20 : # 取得ループ (最大20回)
        com.write('0R0\r\n'.encode())              # wxtに '0R0\r\n' を送る
        response = com.readline().decode().strip() 
        buf = response.split(",")
        if len(buf)==22 : # 1行の応答からカンマ区切りで22項目あるか確認
            now = dt.now(timezone('UTC'))
            with open(_fname, 'a') as f:
                print("%s %s" % (now.strftime("%Y/%m/%d %H:%M:%S"), response), file=f)
            break # 22項目あれば, 時刻スタンプを付けてデータファイルに1行追記して終了
        else : ## error handling
            now = dt.now(timezone('UTC'))
            with open(errorFile, "a") as ferr:
                print("%s wxt Err. trial %d %s" % (now.strftime("%Y/%m/%d %H:%M:%S"), i, response), file=ferr)
            ferr.close()
            time.sleep(10 if i ==9 else 1) # 10回目の施行だけ特別に10秒のインターバル、他は1秒
    com.close() # 全試行に失敗するとループ終了、シリアルポートをクローズ


if __name__ == '__main__':
    if (argc != 2):
        print('Ussage: %s [file name]' % argvs[0])
        quit()
    fsetting = argvs[1]
    daq(getDeviceName(fsetting), getFileName(fsetting))