#!/bin/bash

cd /home/pi/wxt520/src

./daqWxt520.py      setting.txt
./enformatWxt520-2days.sh setting.txt
./plotWxt520-2days.sh     setting.txt
./plotWindWxt520.sh setting.txt
./monitorWxt520.sh  setting.txt


