#!/bin/bash

cd /home/pi/wxt520/src

./getWeatherTelop.sh setting.txt
