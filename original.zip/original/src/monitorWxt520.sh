#!/bin/bash

if [ $# -ne 1 ];then
    echo "Usage: plotWxt520.sh [setting file]. "
    exit
fi

SETTING=$1
FDIR=`cat $SETTING |awk '{if($1=="FILEDIR"){print $2}}'`
NOW=`date +"%Y%m%d"`
NOWDETAIL=`date +"%Y年%m月%d日　%H:%M:%S"`
FDATA=$FDIR/wxt${NOW}.txt

if [ ! -e $FDATA ];then
    echo "No file: $FDATA"
fi
WEBDIR=`cat $SETTING |awk '{if($1=="WEBDIR"){print $2}}'`

DATE=`cat ${WEBDIR}/data/now.dat|awk '{print $1}'`
TIME=`cat ${WEBDIR}/data/now.dat|awk '{print $2}'`
Dn=`cat ${WEBDIR}/data/now-winddirmin.dat`
Dm=`cat ${WEBDIR}/data/now-winddirave.dat`
Dx=`cat ${WEBDIR}/data/now-winddirmax.dat` 
Sn=`cat ${WEBDIR}/data/now-wspeedmin.dat` 
Sm=`cat ${WEBDIR}/data/now-wspeedave.dat` 
Sx=`cat ${WEBDIR}/data/now-wspeedmax.dat` 
TEMP=`cat ${WEBDIR}/data/now-temp.dat` 
HUMI=`cat ${WEBDIR}/data/now-humi.dat`
PRES=`cat ${WEBDIR}/data/now-pres.dat`
Rc=`cat ${WEBDIR}/data/now-rainc.dat` 
Rd=`cat ${WEBDIR}/data/now-raind.dat` 
Ri=`cat ${WEBDIR}/data/now-raini.dat` 
Hc=`cat ${WEBDIR}/data/now-hailc.dat` 
Hd=`cat ${WEBDIR}/data/now-haild.dat` 
Hi=`cat ${WEBDIR}/data/now-haili.dat` 
Rp=`cat ${WEBDIR}/data/now-rainp.dat` 
Hp=`cat ${WEBDIR}/data/now-hailp.dat` 
Th=`cat ${WEBDIR}/data/now-th.dat` 
Vh=`cat ${WEBDIR}/data/now-vh.dat` 
Vs=`cat ${WEBDIR}/data/now-vs.dat` 
Vr=`cat ${WEBDIR}/data/now-vr.dat` 
Info=`cat ${WEBDIR}/data/now-info.dat` 
HUUKOU=`cat ${WEBDIR}/data/now-huukou.dat` 
WeatherTelop=`cat ${WEBDIR}/data/now-weather.dat` 

ORG=${WEBDIR}/index.html.org
MAINTENANCE=${WEBDIR}/index-maintenance.html.org
HTML=${WEBDIR}/index.html

cat $ORG | \
sed 's,_DATE,'$DATE',g'| \
sed 's,_TIME,'$TIME',g'| \
sed 's,_TEMP,'$TEMP',g'| \
sed 's,_HUMI,'$HUMI',g'| \
sed 's,_PRES,'$PRES',g'| \
sed 's,_Sm,'$Sm',g'| \
sed 's,_Sn,'$Sn',g'| \
sed 's,_Sx,'$Sx',g'| \
sed 's,_Dm,'$Dm',g'| \
sed 's,_Dn,'$Dn',g'| \
sed 's,_Dx,'$Dx',g'| \
sed 's,_Rc,'$Rc',g'| \
sed 's,_Rd,'$Rd',g'| \
sed 's,_Ri,'$Ri',g'| \
sed 's,_Rp,'$Rp',g'| \
sed 's,_HUUKOU,'$HUUKOU',g'| \
sed 's,_WeatherTelop,'$WeatherTelop',g'| \
sed 's,_NEW,'${NOWDETAIL}',g' \
> $HTML.test

israin=`echo $Ri|awk '{if($1>0){print 1}else{print 0}}'`
if [ $israin -eq 1 ];then
    mv $HTML.test $HTML.rain
    cat $HTML.rain | sed '/RAINICON/d' > $HTML.test
fi

grep refresh $HTML.test > /dev/null
if [ $? -eq 0 -a ! -e maintenance ];then
    mv $HTML.test $HTML
else 
    HINAN=${WEBDIR}/hinan.html
    mv $HTML.test $HINAN
    cat $MAINTENANCE | sed 's,_NEW,'${NOWDETAIL}',g' > $HTML
fi

