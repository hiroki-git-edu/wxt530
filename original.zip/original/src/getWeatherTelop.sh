#!/bin/bash

if [ $# -ne 1 ];then
    echo "Usage: plotWxt520.sh [setting file]. "
    exit
fi

SETTING=$1
FDIR=`cat $SETTING |awk '{if($1=="FILEDIR"){print $2}}'`
NOW=`date +"%Y%m%d"`
FDATA=$FDIR/wxt${NOW}.txt
if [ ! -e $FDATA ];then
    echo "No file: $FDATA"
fi
WEBDIR=`cat $SETTING |awk '{if($1=="WEBDIR"){print $2}}'`

weather_telop=`curl http://www.tenki.jp/live/3/17/|grep weather_entry_telop|sed 's,[<>], ,g'|awk '{print $5}'`

echo $weather_telop > ${WEBDIR}/data/now-weather.dat 


