#!/usr/bin/env python

import serial
from struct import *

def init(_device):
    com = serial.Serial(port=_device, baudrate=19200, parity=serial.PARITY_NONE, bytesize=serial.EIGHTBITS, stopbits=serial.STOPBITS_ONE, timeout=2)

    print "0XU: initial setting"
    com.write('0XU\r\n')
    response = com.readline()
    print(response)
    print "0XU: setting as "
    com.write('0XU,M=P\r\n')
    response = com.readline()
    print(response)

    print "0WU: initial setting"
    com.write('0WU\r\n')
    response = com.readline()
    print(response)
    print "0WU: setting as "
    com.write('0WU,R=1111110011111100,I=60,A=600\r\n')
    response = com.readline()
    print(response)

    print "0TU: initial setting"
    com.write('0TU\r\n')
    response = com.readline()
    print(response)
    print "0TU: setting as "
    com.write('0TU,R=1101000011010000,I=3\r\n')
    response = com.readline()
    print(response)

    print "0RU: initial setting"
    com.write('0RU\r\n')
    response = com.readline()
    print(response)
    print "0RU: setting as "
    com.write('0RU,R=1111111111111111,Z=M\r\n')
    response = com.readline()
    print(response)

    print "0SU: initial setting"
    com.write('0SU\r\n')
    response = com.readline()
    print(response)
    print "0SU: setting as "
    com.write('0SU,R=1111000011110000,I=600,H=Y\r\n')
    response = com.readline()
    print(response)

    print "0XZ: reset wxt520"
    com.write('0XZ\r\n')
    response = com.readline()
    print(response)

    com.close()
    return 0

if __name__ == '__main__':
    init('/dev/ttyUSB0')
    print 0




