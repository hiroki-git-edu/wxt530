#!/usr/bin/env python
import serial
import time
import sys
from datetime import datetime as dt

now = dt.today()
argvs = sys.argv
argc = len(argvs)

def getFileName(_fname):
    f = open(_fname)
    for line in f:
        data = line[:-1].split(' ')
        if data[0] == "FILEDIR":
            dname = data[1] 
    f.close()
    return dname + "/" + now.strftime("wxt%Y%m%d") + ".txt"

def getDeviceName(_fname):
    f = open(_fname)
    for line in f:
        data = line[:-1].split(' ')
        if data[0] == "DEVICENAME":
            devname = data[1] 
    f.close()
    return devname

def daq(_device, _fname):
    com = serial.Serial(port=_device, baudrate=19200, parity=serial.PARITY_NONE, bytesize=serial.EIGHTBITS, stopbits=serial.STOPBITS_ONE, timeout=2)
    i = 0
    errorFile = _fname + ".err"

    while i<20 :
        com.write('0R0\r\n')
        response = com.readline().strip()
        buf = response.split(",")
        if len(buf)==23 :
            f = open(_fname, 'a')
            print >> f, "%s %s" % (dt.today().strftime("%Y/%m/%d %H:%M:%S"), response)
            f.close()
            break
        else : ## error handling
            ferr = open(errorFile, "a")
            print >> ferr, "%s wxt Err. trial %d %s" % (dt.today().strftime("%Y/%m/%d %H:%M:%S"), i, response)
            ferr.close()
            if i==9 :
                time.sleep(10)
            else :
                time.sleep(1)
            i+=1
    com.close()

    
    
if __name__ == '__main__':
    if (argc != 2):
        print 'Ussage: %s [file name]' % argvs[0]
        quit()
    fsetting = argvs[1]
    daq(getDeviceName(fsetting), getFileName(fsetting))

