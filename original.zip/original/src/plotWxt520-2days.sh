#!/bin/bash
if [ $# -ne 1 ];then
    echo "Usage: plotWxt520.sh [setting file]. "
    exit
fi

SETTING=$1
WEBDIR=`cat $SETTING |awk '{if($1=="WEBDIR"){print $2}}'`

NOW=`date +"%Y/%m/%d %H:%M:%S"`
STRT=`date +"%Y/%m/%d 00:00:00"`
UNAME=`uname`
if [ "$UNAME" = "Darwin" ]; then
    YEST=`date -v-1d +"%Y/%m/%d 00:00:00"`
    END=`date -v+1d +"%Y/%m/%d 00:00:00"`
elif [ "$UNAME" = "Linux" ]; then
    YEST=`date -d '-1 day' +"%Y/%m/%d 00:00:00"`
    END=`date -d '1 day' +"%Y/%m/%d 00:00:00"`
fi

THP="${WEBDIR}/data/thp-2days.dat"
WIN="${WEBDIR}/data/wind-2days.dat"
RAIN="${WEBDIR}/data/rain-hail-2days.dat"
FIGDIR="${WEBDIR}/fig"

#################
ls $THP
echo "debugging"
exit
################

TMAX=`cat $THP|awk 'BEGIN{max=10  }{if($3>max && NF==5){max=$3}}END{printf "%d", max/10}'|awk '{print (($1+1)*10)}'`
TMIN=`cat $THP|awk 'BEGIN{min=0   }{if($3<min && NF==5){min=$3}}END{printf "%d", min}'|awk '{if($1>0){print 0}else{ printf "%d", ($1-10)/10}}'|awk '{print $1*10}'`
PMAX=`cat $THP|awk 'BEGIN{max=10  }{if($5>max && NF==5){max=$5}}END{printf "%d", max/10}'|awk '{print (($1+1)*10)}'`
PMIN=`cat $THP|awk 'BEGIN{min=2000}{if($5<min && NF==5){min=$5}}END{printf "%d", min/10}'|awk '{print (($1-1)*10)}'`
#WMAX=`grep -v "#" $WIN|awk 'BEGIN{max=0 }{if($8>max && NF==8){max=$8}}END{printf "%d", max/5}'|awk '{print (($1+2)*5)}'`
WMAX=`cat $WIN|awk 'BEGIN{max=0 }{if($8>max && NF==8){max=$8}}END{printf "%d", max/5}'|awk '{print (($1+2)*5)}'`
WMIN=0

gnuplot <<EOF
  set xdata time
  set timefmt "%Y/%m/%d %H:%M:%S"
  set format x "%m月%d日"
  set xtics 86400
  set rmargin 5
  set grid x
  set grid mxtics
  set grid y
  set term pngcairo fontscale 1.8 size 640,400

  set output "${FIGDIR}/temp.png"
  set ylabel '温度 [℃]'
  set ytics 5
  plot ["${YEST}":"${END}"]["${TMIN}":"${TMAX}"] \
       '$THP' u 1:3 w l lw 3 notitle #ti "温度 [℃]"

  set output "${FIGDIR}/humi.png"
  set ylabel '湿度 [%]'
  set ytics 20
  plot ["${YEST}":"${END}"][0:100] \
       '$THP' u 1:4 w l lw 3 notitle #ti "湿度 [%]"

  set output "${FIGDIR}/pres.png"
  set ylabel '現地気圧 [hPa]'
  set ytics 10
  plot ["${YEST}":"${END}"]["${PMIN}":"${PMAX}"] \
       '$THP' u 1:5 w l lw 3 notitle #ti "現地気圧 [hPa]"

  set output "${FIGDIR}/wind.png"
  set ylabel '風速 [m/s]'
  set ytics 5
  plot ["${YEST}":"${END}"]["${WMIN}":"${WMAX}"] \
       '$WIN' u 1:8 w l lw 3 ti "最大風速", '$WIN' u 1:7 w l lw 3 ti "平均風速", '$WIN' u 1:6 w l lw 3 ti "最小風速"
EOF

