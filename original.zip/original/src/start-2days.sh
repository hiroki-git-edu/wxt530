#!/bin/bash

cd /home/pi/wxt520/src

./initWxt520.py
./update-2days.sh
