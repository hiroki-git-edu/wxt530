#!/bin/bash

if [ $# -ne 1 ];then
    echo "Usage: plotWxt520.sh [setting file]. "
    exit
fi

SETTING=$1
FDIR=`cat $SETTING |awk '{if($1=="FILEDIR"){print $2}}'`
NOW=`date +"%Y%m%d"`
FDATA=$FDIR/wxt${NOW}.txt
if [ ! -e $FDATA ];then
    echo "No file: $FDATA"
fi
WEBDIR=`cat $SETTING |awk '{if($1=="WEBDIR"){print $2}}'`

# example
# 1 2014/11/04
# 2 15:28:53
# 3 0R0
# 4 Dn=046D 
# 5 Dm=207D
# 6 Dx=011D
# 7 Sn=0.1M
# 8 Sm=0.5M
# 9 Sx=2.0M
# 10 Ta=20.5C
# 11 Tp=21.1C
# 12 Pa=1019.0H
# 13 Rc=0.00M
# 14 Rd=0s
# 15 Ri=0.0M
# 16 Hc=0.0M
# 17 Hd=0s
# 18 Hi=0.0M
# 19 Rp=0.0M
# 20 Hp=0.0M
# 21 Th=19.6C
# 22 Vh=31.9N
# 23 Vs=20.8V
# 24 Vr=3.512V
# 25 Id=Hel

DATA=(`tail -n 1 $FDATA|sed 's.,. .g'`)

# 10 Ta=20.5C # 11 Tp=21.1C # 12 Pa=1019.0H

# 1 2014/11/04
# 2 15:28:53
# 3 0R0

now=`echo ${DATA[0]} ${DATA[1]}` # 4 Dn=046D 
windirmin=`echo ${DATA[3]} |sed 's,Dn=,,g'|sed 's,D,,g'` # 4 Dn=046D 
windirave=`echo ${DATA[4]} |sed 's,Dm=,,g'|sed 's,D,,g'` # 5 Dm=207D
windirmax=`echo ${DATA[5]} |sed 's,Dx=,,g'|sed 's,D,,g'` # 6 Dx=011D
wspeedmin=`echo ${DATA[6]} |sed 's,Sn=,,g'|sed 's,M,,g'` # 7 Sn=0.1M
wspeedave=`echo ${DATA[7]} |sed 's,Sm=,,g'|sed 's,M,,g'` # 8 Sm=0.5M
wspeedmax=`echo ${DATA[8]} |sed 's,Sx=,,g'|sed 's,M,,g'` # 9 Sx=2.0M
temp=`echo ${DATA[9]} |sed 's,Ta=,,g'|sed 's,C,,g'`
humi=`echo ${DATA[10]}|sed 's,Ua=,,g'|sed 's,P,,g'`
pres=`echo ${DATA[11]}|sed 's,Pa=,,g'|sed 's,H,,g'`
rainc=`echo ${DATA[12]} |sed 's,Rc=,,g'|sed 's,M,,g'` # 13 Rc=0.00M
raind=`echo ${DATA[13]} |sed 's,Rd=,,g'|sed 's,s,,g'` # 14 Rd=0s
raini=`echo ${DATA[14]} |sed 's,Ri=,,g'|sed 's,M,,g'` # 15 Ri=0.0M
hailc=`echo ${DATA[15]} |sed 's,Hc=,,g'|sed 's,M,,g'` # 16 Hc=0.0M
haild=`echo ${DATA[16]} |sed 's,Hd=,,g'|sed 's,s,,g'` # 17 Hd=0s
haili=`echo ${DATA[17]} |sed 's,Hi=,,g'|sed 's,M,,g'` # 18 Hi=0.0M
rainp=`echo ${DATA[18]} |sed 's,Rp=,,g'|sed 's,M,,g'` # 19 Rp=0.0M
hailp=`echo ${DATA[19]} |sed 's,Hp=,,g'|sed 's,M,,g'` # 20 Hp=0.0M
th=`echo ${DATA[20]} |sed 's,Th=,,g'|sed 's,C,,g'` # 21 Th=19.6C
vh=`echo ${DATA[21]} |sed 's,Vh=,,g'|sed 's,N,,g'` # 22 Vh=31.9N
vs=`echo ${DATA[22]} |sed 's,Vs=,,g'|sed 's,V,,g'` # 23 Vs=20.8V
vr=`echo ${DATA[23]} |sed 's,Vr=,,g'|sed 's,V,,g'` # 24 Vr=3.512V
info=`echo ${DATA[24]} |sed 's,Id=,,g'`              # 25 Id=Hel

echo "$now"       > ${WEBDIR}/data/now.dat 
echo "$windirmin" > ${WEBDIR}/data/now-winddirmin.dat 
echo "$windirave" > ${WEBDIR}/data/now-winddirave.dat 
echo "$windirmax" > ${WEBDIR}/data/now-winddirmax.dat 
echo "$wspeedmin" > ${WEBDIR}/data/now-wspeedmin.dat 
echo "$wspeedave" > ${WEBDIR}/data/now-wspeedave.dat 
echo "$wspeedmax" > ${WEBDIR}/data/now-wspeedmax.dat 
echo "$temp"      > ${WEBDIR}/data/now-temp.dat 
echo "$humi"      > ${WEBDIR}/data/now-humi.dat
echo "$pres"      > ${WEBDIR}/data/now-pres.dat
echo "$rainc"      > ${WEBDIR}/data/now-rainc.dat 
echo "$raind"      > ${WEBDIR}/data/now-raind.dat 
echo "$raini"      > ${WEBDIR}/data/now-raini.dat 
echo "$hailc"      > ${WEBDIR}/data/now-hailc.dat 
echo "$haild"      > ${WEBDIR}/data/now-haild.dat 
echo "$haili"      > ${WEBDIR}/data/now-haili.dat 
echo "$rainp"      > ${WEBDIR}/data/now-rainp.dat 
echo "$hailp"      > ${WEBDIR}/data/now-hailp.dat 
echo "$th"         > ${WEBDIR}/data/now-th.dat 
echo "$vh"         > ${WEBDIR}/data/now-vh.dat 
echo "$vs"         > ${WEBDIR}/data/now-vs.dat 
echo "$vr"         > ${WEBDIR}/data/now-vr.dat 
echo "$info"       > ${WEBDIR}/data/now-info.dat 

cat $FDATA|sed 's.,. .g'| \
    sed 's,Ta=,,g'|sed 's,Tp=,,g'|sed 's,Pa=,,g'|sed 's,C,,g'|sed 's,H,,g'||sed 's,P,,g'| \
    awk '{print $1,$2,$10,$11,$12}' > ${WEBDIR}/data/thp.dat 

cat $FDATA|sed 's.,. .g'| \
    sed 's,Dn=,,g'|sed 's,Dm=,,g'|sed 's,Dx=,,g'|sed 's,Sn=,,g'|sed 's,Sm=,,g'|sed 's,Sx=,,g'| \
    sed 's,M,,g'|sed 's,D,,g'| \
    awk '{print $1,$2,$4,$5,$6,$7,$8,$9}' > ${WEBDIR}/data/wind.dat 

cat $FDATA|sed 's.,. .g'| \
    sed 's,Rc=,,g'|sed 's,Rd=,,g'|sed 's,Ri=,,g'|sed 's,Hc=,,g'|sed 's,Hd=,,g'|sed 's,Hi=,,g'|sed 's,Rp=,,g'|sed 's,Hp=,,g'| \
    sed 's,M,,g'|sed 's,s,,g'| \
    awk '{print $1,$2,$13,$14,$15,$16,$17,$18,$19,$20}' > ${WEBDIR}/data/rain-hail.dat 


