#!/bin/bash

if [ $# -ne 1 ];then
    echo "Usage: plotWxt520.sh [setting file]. "
    exit
fi
SETTING=$1
WEBDIR=`cat $SETTING |awk '{if($1=="WEBDIR"){print $2}}'`

NOW=`date +"%Y/%m/%d %H:%M:%S"`
UNAME=`uname`
#if [ "$UNAME" = "Darwin" ]; then
#    END=`date -v+1d +"%Y/%m/%d 00:00:00"`
#elif [ "$UNAME" = "Linux" ]; then
#    END=`date -d '1 day' +"%Y/%m/%d 00:00:00"`
#fi

WIN="${WEBDIR}/data/wind.dat"
FIGDIR="${WEBDIR}/fig"

###風向き
declare -a HOUI16=("北" "北北東" "北東" "東北東" "東" "東南東" "南東" "南南東" "南" "南南西" "南西" "西南西" "西" "西北西" "北西" "北北西" "北")
HUUKOU=`cat ${WEBDIR}/data/now-winddirave.dat`
IHUUKOU=`echo $HUUKOU|awk '{printf "%d", ($1+11.25)/22.5}'`
HUUKOU=${HOUI16[$IHUUKOU]}
echo $HUUKOU > ${WEBDIR}/data/now-huukou.dat
###風向き


#WINDIR=`cat ${WEBDIR}/data/now-winddirave.dat|awk '{print (90-$1)/180.0*3.141593}'` #deg->rad
WINDIR=`cat ${WEBDIR}/data/now-winddirave.dat|awk '{print (90-$1)}'`
WINSPD=`cat ${WEBDIR}/data/now-wspeedave.dat`


#X=`echo $WINSPD $WINDIR|awk '{printf "%lf\n", $1*cos($2/180*3.141593)}'`
#Y=`echo $WINSPD $WINDIR|awk '{printf "%lf\n", $1*sin($2/180*3.141593)}'`
#R=`echo $WINSPD|awk '{if($1<5){print 5.0}else{print $1*1.2}}'`
#R=`echo $WINSPD|awk '{print $1*1.2}'`

#echo 0.0 0.0 > ${WEBDIR}/data/now-winddir-vec.dat
#echo $WINDIR $WINSPD >> ${WEBDIR}/data/now-winddir-vec.dat

WINANTI=`expr $WINDIR + 180`
WINTAIL1=`expr $WINDIR + 170`
WINTAIL2=`expr $WINDIR + 190`
echo $WINDIR   1.0 >  ${WEBDIR}/data/now-winddir-vec.dat
echo $WINTAIL1 1.0 >> ${WEBDIR}/data/now-winddir-vec.dat
echo $WINANTI  0.2 >> ${WEBDIR}/data/now-winddir-vec.dat
echo $WINTAIL2 1.0 >> ${WEBDIR}/data/now-winddir-vec.dat
echo $WINDIR   1.0 >> ${WEBDIR}/data/now-winddir-vec.dat



gnuplot << EOF
#set title '$NOW Wind Direction and Speed'
#set title '風向と平均風速'
set size square
set polar
set angle degree
set grid polar
set xlabel "風向:風の吹いてくる方向"
#set style arrow 1 size character 2,20 filled linewidth 2 linetype 1
#set arrow 1 from $X,$Y to 0,0 arrowstyle 1

set term pngcairo fontscale 1.8 size 400,400
set output "${FIGDIR}/wind-vec.png"
set rrange [0:1.2]

unset xtics
unset ytics
set format r ""
plot \
"${WEBDIR}/data/now-winddir-vec.dat" w l lw 4 notitle

#"${WEBDIR}/fig/fig-direction.png" binary filetype=png w rgbalpha

EOF

